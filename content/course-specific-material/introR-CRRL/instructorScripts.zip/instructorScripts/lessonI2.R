#Lesson I: Repeat and reproduce

#if you're starting here, load in nwisData
#cntrl+shift+c will comment or uncomment a 
# highlighted block of code
# nwisData <- read.csv("data/course_NWISdata.csv",
#                      stringsAsFactors = FALSE,
#                      colClasses = c('character', rep(NA, 6)))

#make your own functions
function_name <- function(requiredArg, optionalArg="default") {
  # whatever code we want
  text <- paste(requiredArg, optionalArg)
  z <- 7
  return(text)
  x <- 3 #code after a return statement won't be run
  y <- 4
}

val <- function_name("some text", optionalArg = "here")
val

#create a function
sumsquares <- function(x) {
  total <- 0
  for (val in x) {
    total = total + val^2
  }
  return(total)
}

#call the new function
y <- sumsquares(c(1,3,7))
min <- min(c(1,3,7))

#make plots inside a function
plot_do_temp <- function(df, siteid, color="red") {
  filename <- file.path("plots", paste(siteid, "DOTemp.png", sep = ""))
  library(dplyr)
  sitedf <- filter(df, site_no == siteid)
  png(filename=filename, width=900, height=900)
  plot(sitedf$Wtemp_Inst, sitedf$DO_Inst, main=siteid, col=color, pch=16)
  legend("topright", legend="Water temp vs DO", col=color, pch=16)
  dev.off()
}

sites <- unique(nwisData$site_no)
sites
plot_do_temp(nwisData, "02336240")
plot_do_temp(nwisData, "02336120", color="purple")

mydir <- "plots/go/here"
if (!dir.exists(mydir)) {
  dir.create(mydir, recursive=TRUE)
}
cols <- rainbow(length(sites))
#make a plot for each unique site using a loop and the function
#we made
for (i in 1:length(sites)) {
  plot_do_temp(nwisData, sites[i], color=cols[i])
}



