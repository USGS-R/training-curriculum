#Lesson C: clean

#if you're starting here, load in nwisData
#cntrl+shift+c will comment or uncomment a 
#highlighted block of code
# nwisData <- read.csv("data/course_NWISdata.csv", 
#                      stringsAsFactors = FALSE, 
#                      colClasses = c('character', rep(NA, 6)))

#get the data frame structure
str(nwisData)  

#access specific rows or columns of nwisData by number
var <- nwisData[1,]
col <- nwisData[,1]
col
col2 <- nwisData[,c(2,4,7)]
col3 <- nwisData[10:20,c(3,6)]

seq(10,20) #makes a sequence of numbers, same as 10:20

col4 <- nwisData[,c(TRUE,FALSE)]
head(col4)

col5 <- nwisData[nwisData$Flow_Inst > 30,]
head(col5)
dim(col5)

#access columns by name
flowInst <- nwisData$Flow_Inst
head(flowInst)
flowInst2 <- nwisData[['Flow_Inst']]
tail(flowInst2)

#reference vector elements by position and logically
vect <- c(1,2,3,4,11)
vect[4]
vect[c(1,5)]
vect[c(TRUE, FALSE, FALSE, TRUE, FALSE)]
vect[c(TRUE, FALSE)] #references every other row

#filter a row using base R
estimated <- nwisData$Flow_Inst[nwisData$Flow_Inst_cd == 'E']
estimated2 <- nwisData$Flow_Inst[nwisData$Flow_Inst > 5000]
length(estimated)
head(estimated)


# count how many values are NOT NA
sum(!is.na(estimated))
mean(estimated, na.rm = TRUE)

#logical comparisons - "equals"
TRUE == FALSE
1 == 1
!TRUE # exclamation negates the logic


library(dplyr) #Load the dplyr package
#use dplyr to select and reorder columns
dplyr_select <- select(nwisData, site_no, dateTime, Flow_Inst)
dateTimeFirst <- select(nwisData, dateTime, site_no, DO_Inst)
names(dplyr_select) #list all the column names in a data frame
names(dateTimeFirst)
head(dplyr_select)
smaller <- select(dplyr_select, site_no, Flow_Inst)
head(smaller)

#defining some column names with select and rename
renamed <- select(nwisData, site_no=site_no, 
                  date_time = dateTime, 
                  flow_inst = Flow_Inst)
names(renamed)
rename_keeping_all <- rename(nwisData, date_time=dateTime)
names(rename_keeping_all)

# filter data by value
filtered <- filter(nwisData, Wtemp_Inst > 15)
dim(filtered)
filtered <- filter(nwisData, Wtemp_Inst > 25)
dim(filtered)

estimated2 <- filter(nwisData, Flow_Inst_cd == 'E')
length(estimated2) # columns
nrow(estimated2)
head(estimated2)

na_removed <- filter(nwisData, !is.na(Wtemp_Inst))
head(na_removed)
nrow(na_removed)
more_na_removed <- filter(nwisData, !is.na(Wtemp_Inst)
                          & !is.na(DO_Inst))
nrow(more_na_removed)

#logical comparisons: and, or
TRUE && FALSE
TRUE && TRUE
FALSE && FALSE
c(TRUE, TRUE) & c(TRUE, FALSE)

TRUE | TRUE
TRUE | FALSE
FALSE | FALSE
TRUE || FALSE

#mutate adds a new column
mutated_nwis <- mutate(nwisData, DO_mgmL = DO_Inst / 1000)
head(mutated_nwis)
est_nwis <- mutate(nwisData, Est = Flow_Inst_cd == "E")
head(filter(est_nwis, Est == TRUE))
nrow(filter(est_nwis, Est == TRUE))


# nwisData <- rename(nwisData, Flow=Flow_Inst, 
#                    Flow_cd=Flow_Inst_cd,
#                    Wtemp=Wtemp_Inst, 
#                    pH=pH_Inst, DO=DO_Inst)
removed <- select(nwisData, -Flow_Inst_cd)
names(removed)
conversion <- 3.28^3
with_cubic_meters <- mutate(nwisData, Flow_meters = Flow_Inst / conversion)


new_data <- data.frame(site_no=rep("00000001", 3), 
                       dateTime=c("2016-09-01 07:45:00", "2016-09-02 07:45:00", "2016-09-03 07:45:00"), 
                       Wtemp_Inst=c(14.0, 16.4, 16.0),
                       pH_Inst = c(7.8, 8.5, 8.3),
                       stringsAsFactors = FALSE)
head(new_data)
new_nwis <- bind_rows(nwisData, new_data)
tail(new_nwis)
names(new_nwis)

#create some new data to add
#realistically this would just be loading a new file
forgotten_data <- data.frame(site_no=rep("00000001", 5),
                             dateTime=c("2016-09-01 07:45:00", "2016-09-02 07:45:00", "2016-09-03 07:45:00",
                                        "2016-09-04 07:45:00", "2016-09-05 07:45:00"),
                             DO_Inst=c(10.2,8.7,9.3,9.2,8.9),
                             Cl_conc=c(15.6,11.0,14.2,13.6,13.7),
                             Flow_Inst=c(25,54,67,60,59),
                             stringsAsFactors = FALSE)
head(forgotten_data)
#dplyr has several join functions, look at the help
#to see the differences.  Similar to other database languages
joined <- left_join(new_data, forgotten_data,
                    by=c("site_no", "dateTime"))
head(joined)
right_joined <- right_join(new_data, forgotten_data,
                    by=c("site_no", "dateTime"))
head(right_joined)

#group a data frame by a certain variable
grouped_nwis <- group_by(nwisData, site_no)
head(grouped_nwis)
nrow(grouped_nwis)

#now can get statistics for each group
#other functions can be used here besides mean()
summarized <- summarize(grouped_nwis, 
                        Mean_flow=mean(Flow_Inst, na.rm=TRUE),
                        Mean_temp=mean(Wtemp_Inst, na.rm=TRUE))
head(summarized)

# sorting by mean
sorted <- arrange(summarized, Mean_flow)
head(sorted)
descending <- arrange(summarized, desc(Mean_temp), site_no)
head(descending)

# slice data 
sliced <- slice(nwisData, 7:12)
head(sliced)

# can do operations rowwise rather than column-wise
#?rowwise
new_do <- mutate(nwisData, DO_2=
                   runif(n=nrow(nwisData), min=5.0, max=10.0))
head(new_do)
new_do <- mutate(new_do, max_DO = max(DO_Inst, DO_2))
head(new_do)
new_do <- rowwise(new_do)
new_do <- mutate(new_do, max_DO = max(DO_Inst, DO_2))
head(new_do$max_DO)
new_do <- ungroup(new_do) #undoes grouping, and rowwise
class(new_do)

# introducing pipes (magrittr) for exercise 3
summary <- nwisData %>%
  group_by(site_no) %>%
  summarize_at(vars(Flow_Inst, Wtemp_Inst, DO_Inst), 
               min, na.rm=TRUE)
head(summary)
