#using ScienceBase with R

install.packages('sbtools')
library(sbtools)
authenticate_sb() #log in

#create, add, remove files
workshop_fld <- item_create(title='Jordan W workshop')

workshop_fld
item_append_files(workshop_fld, 
                  files=file.path('data',dir('data')))

item_append_files('581a6513e4b0bb36a4ca3070', 
                  files=c('data/IonBalance.csv', 'do_vs_wtemp.png'))

item_file_download('581a6513e4b0bb36a4ca3070',names = 'do_vs_wtemp.png',
                   destinations = 'data/new_plot.png')

item_rm('581a6513e4b0bb36a4ca3070')
