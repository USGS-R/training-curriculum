print('today is a lovely day')
rnorm(10) #10 random numbers with normal distribution

# next I will install a package
install.packages('dplyr')
#get the manual for that package
help(package = "dplyr")

#search the help for something
??dplyr
#get help on a specific function
?mutate