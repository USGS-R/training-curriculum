#visualize with base R
#if you're starting here, load in nwisData
#cntrl+shift+c will comment or uncomment a 
# highlighted block of code
# nwisData <- read.csv("data/course_NWISdata.csv",
#                      stringsAsFactors = FALSE,
#                      colClasses = c('character', rep(NA, 6)))


library(dplyr)
nwisData_est <- filter(nwisData, Flow_Inst_cd == "E")
nwisData_est_QDO <- select(nwisData_est, Flow_Inst, 
                           DO_Inst)
nwisData_err <- filter(nwisData, Flow_Inst_cd == "X")
nwisData_err_QDO <- select(nwisData_err, Flow_Inst, 
                           DO_Inst)

#col for different colors, pch for shapes
#google for options
#points adds to existing axes
plot(nwisData_err_QDO$Flow_Inst, nwisData_err_QDO$DO_Inst,
     pch = 16, col = "skyblue")
points(nwisData_est_QDO$Flow_Inst, nwisData_est_QDO$DO_Inst,
       pch = 16, col = "red")

#save default par arguments
default_par <- par(no.readonly = TRUE)

#this will affect future plots until par is reset
par(las=2, tck=0.01, bg = "darkseagreen")
plot(nwisData_err_QDO$Flow_Inst, nwisData_err_QDO$DO_Inst,
     pch = 6)
dev.off() #turns off existing graphics device to start fresh 
graphics.off() #closes ALL graphics devices (so you don't need to 
#multiple dev.off() calls)

#remake this plot; par changes are gone
plot(nwisData_err_QDO$Flow_Inst, nwisData_err_QDO$DO_Inst,
     pch = 16, col = "skyblue")
points(nwisData_est_QDO$Flow_Inst, nwisData_est_QDO$DO_Inst,
       pch = 16, col = "red")

#legend
legend(x = "topright", legend = c("Erroneous flows","Estimated Flows"),
       pch = 16, col = c("skyblue", "red"), title = "Legend")

#plot a curve
curve(x^2, from = 0, to = 10)

#plot a line
plot(1:15, c(1:7, 9.5, 9:15), type = "l")
rect(xleft = 6, xright = 9, ybottom = 5, ytop = 11,
     density = 5, col = "orange")
polygon(x = c(2,3,4), y=c(2,6,2), col="lightgreen",
        border = NA)

#additional axes
plot(nwisData$Flow_Inst, nwisData$Wtemp_Inst, 
     pch = 20)
axis(side = 4)

#with no axes to start or box around plot
plot(nwisData$Flow_Inst, nwisData$Wtemp_Inst, 
     pch = 20, axes = FALSE, bty = "n")
box() # box around the plot
axis(side = 4)
axis(side = 1)

#log axes
plot(nwisData$Flow_Inst, nwisData$Wtemp_Inst, 
     pch = 20, log = 'x')
axis(side = 4, at = 1:20, labels = FALSE)
axis(side = 3)

#make a grid of plots
layout_matrix <- matrix(c(1:4), nrow = 2, ncol = 2,
                        byrow = TRUE)
layout(layout_matrix)

#each plot will go into a cell in the layout
plot1 <- boxplot(nwisData$Flow_Inst ~ nwisData$site_no, 
                 ylab = 'Discharge (cfs)', main = "Discharge")
plot2 <- boxplot(nwisData$Wtemp_Inst ~ nwisData$site_no, 
                 ylab = 'Temperature, deg C', main = "Water Temp")
#see what is in layout_matrix
print(layout_matrix) #numbers correspond to order plot quadrant will fill

plot3 <- boxplot(nwisData$pH_Inst ~ nwisData$site_no,
                 ylab = "pH", main = "pH")
plot4 <- boxplot(nwisData$DO_Inst ~ nwisData$site_no, 
                 ylab = "D.O. Concentration", main = "Dissolved Oxygen")
dev.off()

#save to a file
png(file = "do_vs_wtemp.png", width = 5, height = 6,
    units = "in", res = 300)
#now this plot will go to the png
plot(nwisData$Wtemp_Inst, nwisData$DO_Inst)
dev.off() #this actually saves the file

plot(nwisData$Wtemp_Inst, nwisData$DO_Inst,
     main = "DO vs Water Temp")
#add a subtitle
mtext("subtitle")
mtext("subtitle 2", line = 1)

#text anywhere
text(x = 15, y = 4, labels = "label")
#using grconvert to change coordinate systems
text(x = grconvertX(0.1, "npc"), 
     y = grconvertY(0.5, "npc"),  
     label = "label with grconvert")