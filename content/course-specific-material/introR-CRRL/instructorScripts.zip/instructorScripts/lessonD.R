#Lesson D: Explore

#if you're starting here, load in nwisData
#cntrl+shift+c will comment or uncomment a 
# highlighted block of code
# nwisData <- read.csv("data/course_NWISdata.csv",
#                      stringsAsFactors = FALSE,
#                      colClasses = c('character', rep(NA, 6)))

#get some info on the whole data frame and specific columns
summary(nwisData)
dataRange <- range(nwisData$Flow_Inst, na.rm=TRUE)
dataRange

iqr <- IQR(nwisData$Wtemp_Inst, na.rm=TRUE)
iqr

# get the quantiles
quant <- quantile(nwisData$pH_Inst, na.rm=TRUE)
quant

# plot some data
plot(nwisData$Wtemp_Inst, nwisData$DO_Inst)

#prettier plot
plot(nwisData$Wtemp_Inst, nwisData$DO_Inst,
     main="Changes in DO conc as a function of water temp",
     xlab="Water Temperature, deg C",
     ylab="Dissolved oxygen concentration, mg/L")

library(dplyr) #remove specific columns with dplyr
explore_plot <- select(nwisData, -site_no, -dateTime,
                       -Flow_Inst_cd)
plot(explore_plot)

# look at just one site (with other dplyr functions)
sites <- unique(nwisData$site_no)
sites
single_site <- filter(nwisData, site_no == sites[4])
same_as_above <- filter(nwisData, site_no == "02336240")
explore_plot2 <- select(single_site, -site_no, -dateTime,
                       -Flow_Inst_cd)
plot(explore_plot2)

#boxplots
boxplot(nwisData$DO_Inst, main="boxplot", 
        ylab="Concentration")

box <- boxplot(nwisData$DO_Inst ~ nwisData$site_no,
        main="DO by site", ylab="Concentration")
box

# let's do a histogram
hist_out <- hist(nwisData$pH_Inst)
hist_out

hist_out2 <- hist(nwisData$pH_Inst, breaks=4)
hist_out2

# now a ecdf
ecdf_out <- ecdf(nwisData$Wtemp_Inst)
ecdf_out
plot(ecdf_out, xlab="Water Temperature, deg C",
     main="Cumulative Distribution", ylab="ECDF")


