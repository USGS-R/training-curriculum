#Lesson B: Get

#here is an object
testObject <- 6
print(testObject) #print object in console
object2 <- testObject #assigning another object the same value

#logical object
logical <- FALSE

#a vector
sampleVector <- c(3,1,9,4)
#a longer vector
longVector <- c(sampleVector, 5,3,2)
logVector <- rep(TRUE, 7)

# create a data frame from two vectors
#specifying column names
df <- data.frame(numeric_vector = longVector, 
                 logical_vector = logVector, 
                 stringsAsFactors = FALSE)

#list everything in your workspace
ls()
#rm() to remove an object
rm(object2)

#check the working directory path
getwd()
#setwd('your/path') to change


#actually load some data
nwisData <- read.csv("data/course_NWISdata.csv")

#look at top and bottom
head(nwisData)
tail(nwisData)
View(nwisData) #brings up the data in a new pane
#looks like some data types aren't what we want

#read in the data with the right types
#we'll use this data frame for the rest of the course
nwisData <- read.csv("data/course_NWISdata.csv", 
                     stringsAsFactors = FALSE, 
                     colClasses = c('character', rep(NA, 6)))
#write it to a csv
write.csv(nwisData, file = "nwisWrite.csv")

#read an excel file
library(readxl)
excelData <- read_excel('data/gwlevels.xlsx')
#use the sheets argument to specify a sheet other than one
?read_excel