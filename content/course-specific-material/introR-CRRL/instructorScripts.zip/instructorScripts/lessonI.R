#Lesson I: Repeat and reproduce

#if you're starting here, load in nwisData
#cntrl+shift+c will comment or uncomment a 
# highlighted block of code
# nwisData <- read.csv("data/course_NWISdata.csv",
#                      stringsAsFactors = FALSE,
#                      colClasses = c('character', rep(NA, 6)))

#basic if statement
x <- 2

if (x > 3) {
  print("yes")
}


# add an else
if (x > 3) {
  y <- 4
  z <- 7
} else {
  y <- 2
  z <- 11
}

if (x < 10) {
  warning("x is less than ten") #print a warning message
}

#more complex if else if 
# if - elseif - else
if (x > 3) {
  print("yes")
} else if (x == 2) {
  print("maybe")
} else {
  print("no")
}

#different forms of multiple conditions
if (x < 0 && y < 10) {
  print("do something here")
}

a <- c(TRUE, TRUE, FALSE)
b <- c(1, 5, 12)
if (all(a)) {
  print("all true")
}
if (any(a)) {
  print("any true")
}
if (all(b > 0)) {
  print("positive")
}


# if we have lots of rows filter
library(dplyr)
if (nrow(nwisData) > 1000) {
  smaller <- filter(nwisData, Wtemp_Inst < 15)
}

# for loop adding numbers
x <- 1
for (i in 1:100) {
  x <- x + i
}
x

#can loop over each element in a vector without specific number index
words <- c("dog", "cat", "fish", "dinosaur")
for (word in words) {
  new_word <- paste(word, "is a creature")
  print(new_word)
}
print(words)

vars <- names(nwisData)
vars <- c("Flow_Inst", "Wtemp_Inst", "pH_Inst", "DO_Inst")
myData <- NULL
for (var in vars) {
  myData <- bind_cols(myData, nwisData[var])
}

# solution for exercise 2
library(dplyr)
sites <- unique(nwisData$site_no)
for (siteid in sites) {
  if (siteid != "02336526") {
    tmpdf <- filter(nwisData, site_no == siteid)
    plot(tmpdf$Wtemp_Inst, tmpdf$DO_Inst, 
      main=paste("Water temp vs. DO at", siteid))
  }
}

