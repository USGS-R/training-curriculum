#Lesson E: Analyze

#if you're starting here, load in nwisData
#cntrl+shift+c will comment or uncomment a 
# highlighted block of code
# nwisData <- read.csv("data/course_NWISdata.csv",
#                      stringsAsFactors = FALSE,
#                      colClasses = c('character', rep(NA, 6)))

#t test on 2 randomly generated populations
pop1 <- rnorm(30, mean=3, sd=2)
pop1
pop2 <- rnorm(30, mean=10, sd=5)
pop_ttest <- t.test(pop1, pop2)
pop_ttest

library(dplyr)
#use dplyr to pull out 2 subsets of nwisData for more stats
estimatedF <- filter(nwisData, Flow_Inst_cd == "E")
extrapolatedF <- filter(nwisData, Flow_Inst_cd == "X")
dim(estimatedF)
dim(extrapolatedF)

flow_ttest <- t.test(estimatedF$Flow_Inst, extrapolatedF$Flow_Inst)

cor(nwisData$Wtemp_Inst, nwisData$DO_Inst, use = "complete.obs")
cor.test(nwisData$Wtemp_Inst, nwisData$DO_Inst)

#linear model
lm(formula = DO_Inst ~ Wtemp_Inst, data = nwisData)

lm_result <- lm(formula = DO_Inst ~ Wtemp_Inst, data = nwisData)
lm_result

summary(lm_result)

# just grab coefficients:
lm_result$coefficients
slope <- lm_result$coefficients[2]

#plot it
plot(nwisData$Wtemp_Inst, nwisData$DO_Inst)
abline(lm_result)

plot(nwisData$Wtemp_Inst, nwisData$DO_Inst)
abline(h=11)
abline(v=15)
abline(a=7, b = 0.5)
